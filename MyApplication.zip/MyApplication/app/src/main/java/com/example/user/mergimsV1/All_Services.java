package com.example.user.mergimsV1;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

public class All_Services extends AppCompatActivity {

    TextView Airtime,Tv,Bus,Electricity,Others;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_services);

        Airtime =(TextView) findViewById(R.id.Airtime);
        Tv =(TextView) findViewById(R.id.Tv);
        Bus =(TextView) findViewById(R.id.Bus);
        Electricity =(TextView) findViewById(R.id.Electricity);
        Others =(TextView) findViewById(R.id.Others);

        Airtime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent airtime=new Intent(All_Services.this,AirTimesDetails.class);
                startActivity(airtime);

            }
        });

        Tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Intent tv=new Intent(All_Services.this, com.example.user.mergimsV1.TvDetails.class);
                startActivity(tv);


            }
        });

        Bus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent bus=new Intent(All_Services.this, com.example.user.mergimsV1.FacebookLogin1.class);
                startActivity(bus);

            }
        });

        Electricity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Intent electricity=new Intent(All_Services.this, com.example.user.mergimsV1.FacebookLogin1.class);
                startActivity(electricity);

            }
        });

        Others.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {



            }
        });

    }
}


