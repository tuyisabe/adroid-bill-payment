package com.example.user.mergimsV1;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

public class AirTimesDetails extends AppCompatActivity {

    TextView mtn,tigo,airtel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_air_times_details);

        mtn = (TextView) findViewById(R.id.mtn);
        tigo = (TextView) findViewById(R.id.tigo);
        airtel = (TextView) findViewById(R.id.airtel);

    }
}
