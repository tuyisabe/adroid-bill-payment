package com.example.user.mergimsV1;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

public class TvDetails extends AppCompatActivity {

    TextView Startime,dstv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tv_details);

        Startime =(TextView) findViewById(R.id.Startime);
        dstv = (TextView) findViewById(R.id.dstv);
    }
}
